<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Sapaan</title>
</head>
<body>
<nav>
   <nav>
    <a href="/profil">Profil</a> | 
    <a href="/sapa/Rama">Sapa</a> | 
    <a href="/mapel">Mapel</a>
</nav>
    <hr>

    <h1>Halo, <?php echo e($nama); ?>! Selamat datang.</h1>
</body>
</html><?php /**PATH C:\laragon\www\laravel defi\resources\views/sapa.blade.php ENDPATH**/ ?>